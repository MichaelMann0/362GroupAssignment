import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import './LoginForm.css';

const LoginForm = ({ userType, onSubmit, onSwitchToRegister }) => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const { login, error } = useAuth();
  const [localError, setLocalError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setLocalError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLocalError('');
    setIsLoading(true);

    try {
      const user = await login(formData.email, formData.password);
      console.log('Login successful:', user);
      if (onSubmit) {
        onSubmit({
          ...formData,
          userType,
          user
        });
      }
    } catch (err) {
      console.error('Login error:', err);
      setLocalError(err.message || 'Login failed. Please check your email and password.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form className="login-form" onSubmit={handleSubmit}>
      {/* Sign up link - make it more prominent */}
      {onSwitchToRegister && (
        <div style={{ 
          textAlign: 'center', 
          marginBottom: '24px', 
          padding: '12px',
          background: '#f0f8f5',
          borderRadius: '8px',
          border: '1px solid #006A4E'
        }}>
          <p style={{ margin: 0, fontSize: '0.95em', color: '#2c3e50' }}>
            Don't have an account?{' '}
            <button
              type="button"
              onClick={onSwitchToRegister}
              style={{
                background: 'none',
                border: 'none',
                color: '#006A4E',
                cursor: 'pointer',
                textDecoration: 'underline',
                fontWeight: '700',
                fontSize: '1em',
                padding: '0',
                marginLeft: '4px'
              }}
            >
              Sign up here
            </button>
          </p>
        </div>
      )}

      <div className="form-group">
        <label htmlFor="email" className="form-label">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          className="form-input"
          placeholder="Enter your email"
          required
          disabled={isLoading}
        />
      </div>
      
      <div className="form-group">
        <label htmlFor="password" className="form-label">Password</label>
        <input
          type="password"
          id="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          className="form-input"
          placeholder="Enter your password"
          required
          disabled={isLoading}
        />
      </div>

      {/* Error messages */}
      {(error || localError) && (
        <div style={{
          color: '#d32f2f',
          fontSize: '0.9em',
          marginBottom: '15px',
          padding: '12px',
          background: '#ffebee',
          borderRadius: '8px',
          border: '1px solid #ffcdd2'
        }}>
          <strong>Error:</strong> {localError || error}
        </div>
      )}

      <button 
        type="submit" 
        className="login-button"
        disabled={isLoading}
        style={{
          opacity: isLoading ? 0.7 : 1,
          cursor: isLoading ? 'not-allowed' : 'pointer'
        }}
      >
        {isLoading ? 'Logging in...' : 'Login'}
      </button>
    </form>
  );
};

export default LoginForm;